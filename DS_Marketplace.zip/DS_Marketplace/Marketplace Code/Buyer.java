import java.io.*;
import java.net.Socket;
import java.util.Properties;
import java.util.Scanner;

// The Buyer class represents a client in the marketplace system.
public class Buyer {
    // Fields to store the buyer's ID, server host, port, and connection status.
    private int id;
    private String host;
    private int port;

    // Constructor for the Buyer class.
    public Buyer() {
    }

    // Method to initiate a purchase with a specified quantity.
    public void initiatePurchase(int quantity) {
        try (
            // Establish a connection to the server.
            Socket socket = new Socket(host, port);
            // Output stream to send data to the server.
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            // Input stream to receive data from the server.
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()))
        ) {
            // Send a purchase request to the server.
            output.println("PURCHASE " + quantity + " " + id);

            // Read the server's response and print it.
            String serverResponse = input.readLine();
            System.out.println("SERVER: " + serverResponse);

        } catch (IOException e) {
            // Handle exceptions related to input/output operations.
            System.err.println("PURCHASE FAILED");
            e.printStackTrace();
        }
    }

    // Method to engage with the marketplace, allowing the buyer to make multiple purchase requests.
public void engageWithMarket() {
    try (
        // Establish a connection to the server.
        Socket socket = new Socket(host, port);
        PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
        BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        // Scanner to read user input from the console.
        Scanner userInputScanner = new Scanner(System.in)
    ) {
        // Send the buyer's ID to the server immediately after establishing the connection.
        output.println("BUYER_ID:" + id);

        // Create a new thread to listen to messages from the server.
        Thread serverMessageListener = new Thread(() -> {
            try {
                String serverMessage;
                // Continuously read messages from the server and print them.
                while ((serverMessage = input.readLine()) != null) {
                    System.out.println("SERVER: " + serverMessage);
                }
            } catch (IOException e) {
                System.out.println("SERVER ERROR: LOST CONNECTION");
            }
        });

        // Start the server message listener thread.
        serverMessageListener.start();

        // Main loop for handling user input and sending purchase requests.
        while (true) {
            System.out.println("Enter the quantity to purchase, or type 'exit' to disconnect:");
            String userCommand = userInputScanner.nextLine();

            // Check if the user wants to exit.
            if ("exit".equalsIgnoreCase(userCommand)) {
                break;
            }

            try {
                // Attempt to parse the user input as an integer and send a purchase request.
                int quantity = Integer.parseInt(userCommand);
                output.println("PURCHASE " + quantity + " " + id);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please try again");
            }
        }

        System.out.println("Disconnecting... Thank you for using the Marketplace");
        serverMessageListener.interrupt();
    } catch (IOException e) {
        System.err.println("SERVER ERROR: DID NOT CONNECT: " + e.getMessage());
        e.printStackTrace();
    }
}


    // Method to load buyer properties (like ID, host, and port) from a properties file.
    public void loadBuyerProperties(String buyerConfigKey, Properties properties) {
        this.id = Integer.parseInt(properties.getProperty(buyerConfigKey + ".id"));
        this.host = properties.getProperty(buyerConfigKey + ".serverAddress");
        this.port = Integer.parseInt(properties.getProperty(buyerConfigKey + ".serverPort"));
    }

    // The main method to start the Buyer application.
    public static void main(String[] args) {
        // Load properties from the 'Marketplace.properties' file.
        Properties properties = new Properties();
        try {
            properties.load(new FileReader("Marketplace.properties"));
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // Check if a buyer number is provided as an argument.
        if (args.length < 1) {
            System.out.println("Who is trying to connect to the Marketplace? Please insert Buyer number");
            return;
        }

        // Construct the buyer configuration key based on the argument provided.
        String buyerConfigKey = "buyer" + args[0];

        // Create a new Buyer instance and load its properties.
        Buyer buyer = new Buyer();
        buyer.loadBuyerProperties(buyerConfigKey, properties);

        // Check if the host and port are properly configured.
        if (buyer.host == null || buyer.port == 0) {
            System.out.println("SERVER ERROR: PROPERTIES NOT BEING READ PROPERLY");
            return;
        }

        // Engage with the marketplace.
        buyer.engageWithMarket();

        // Scanner to read the final purchase quantity from the user.
        Scanner scanner = new Scanner(System.in);
        System.out.println("How much would you like to buy?:");
        int quantity;
        try {
            // Parse the user input as an integer.
            quantity = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            // Handle invalid input that is not an integer.
            System.out.println("Invalid quantity of goods. Please try again");
            scanner.close();
            return;
        }

        // Initiate the final purchase with the specified quantity.
        buyer.initiatePurchase(quantity);
        scanner.close();
    }
}
