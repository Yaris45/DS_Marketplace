import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

// Seller class implements Runnable to be used in a separate thread.
public class Seller implements Runnable {
    private final int id; // Seller's unique ID
    private final ConcurrentHashMap<String, Integer> inventory = new ConcurrentHashMap<>(); // Thread-safe inventory storage
    private String activeItem; // The current item being sold
    private final int listeningPort; // The port that this seller listens on
    private final Timer inventoryRotationTimer = new Timer(); // Timer for rotating inventory items
    private final List<PrintWriter> connectedBuyers = Collections.synchronizedList(new ArrayList<>()); // List of connections to buyers

    // Constructor initializes the seller with an ID and a port.
    public Seller(int id, int listeningPort) {
        this.id = id;
        this.listeningPort = listeningPort;
        this.activeItem = "POTATO"; // Default active item
        scheduleInventoryRotation(); // Initialize inventory rotation
    }

    // Getter for inventory stock.
    public ConcurrentHashMap<String, Integer> getStock() {
        return inventory;
    }

    // Getter for the current item on sale.
    public String getCurrentItem() {
        return activeItem;
    }

    // Initialize inventory based on properties file.
    public void initializeInventory(Properties properties) {
        try {
            // Load inventory items from properties file.
            inventory.put("FLOUR", Integer.parseInt(properties.getProperty("seller" + id + ".stock.FLOUR", "0")));
            inventory.put("SUGAR", Integer.parseInt(properties.getProperty("seller" + id + ".stock.SUGAR", "0")));
            inventory.put("POTATO", Integer.parseInt(properties.getProperty("seller" + id + ".stock.POTATO", "0")));
            inventory.put("OIL", Integer.parseInt(properties.getProperty("seller" + id + ".stock.OIL", "0")));
        } catch (NumberFormatException e) {
            System.out.println("SERVER ERROR: INVENTORY VALUES IN PROPERTIES NOT PARSING CORRECTLY");
            e.printStackTrace();
        }
        System.out.println("SELLER " + id + " IS NOW SELLING " + activeItem);
        activeItem = inventory.keySet().iterator().next(); // Set the first item in inventory as active item
    }

    @Override
    public void run() {
        try (ServerSocket serverSocket = new ServerSocket(listeningPort)) {
            System.out.println("Marketplace is now live! Using PORT:" + listeningPort);
            while (true) {
                Socket buyerSocket = serverSocket.accept(); // Accept connections from buyers
    
                handleBuyerConnection(buyerSocket); // Handle each buyer connection in a separate thread
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Handles individual buyer connections.
    private void handleBuyerConnection(Socket buyerSocket) {
        new Thread(() -> {
            PrintWriter output = null; // Stream for sending data to the buyer
            try (buyerSocket;
                 BufferedReader input = new BufferedReader(new InputStreamReader(buyerSocket.getInputStream()))) {
    
                output = new PrintWriter(buyerSocket.getOutputStream(), true); // Stream for receiving data from the buyer
    
                // Read the initial message which should be the buyer's ID
                String initialMessage = input.readLine();
                int buyerId = -1; // Initialize with an invalid ID
                if (initialMessage != null && initialMessage.startsWith("BUYER_ID:")) {
                    try {
                        buyerId = Integer.parseInt(initialMessage.substring("BUYER_ID:".length()));
                        System.out.println("BUYER " + buyerId + " HAS CONNECTED TO THE MARKETPLACE.");
                    } catch (NumberFormatException e) {
                        System.out.println("SERVER ERROR: BUYER DID NOT CONNECT");
                    }
                }
    
                addBuyerConnection(output); // Add this buyer to the connected buyers list
                output.println("CURRENTLY SELLING: " + getCurrentItem() + " -> AMOUNT LEFT: " + getStock().get(getCurrentItem()));
    
                String inputLine;
                while ((inputLine = input.readLine()) != null) { // Read buyer's requests
                    String[] requestDetails = inputLine.split(" ");
                    if ("PURCHASE".equals(requestDetails[0]) && requestDetails.length == 3) {
                        int amount = Integer.parseInt(requestDetails[1]);
                        // Use the received buyerId instead of parsing from the request
                        String product = getCurrentItem();
                        boolean successful = executeTransaction(product, amount, buyerId); // Process the transaction
                        if (successful) {
                            output.println("PURCHASE SUCCESSFUL: " + amount + " -> AMOUNT: " + product);
                        } else {
                            output.println("PURCHASE FAILED. NOT ENOUGH GOODS " + product);
                        }
                    }
                }
            } catch (IOException e) {
                System.out.println("CONNECTION ERROR: " + e.getMessage());
            } finally {
                if (output != null) {
                    removeBuyerConnection(output); // Remove buyer from the connected buyers list
                }
            }
        }).start();
    }
    
    
    // Notify all connected buyers with a message.
    private void updateAllBuyers(String message) {
        synchronized (connectedBuyers) {
            for (PrintWriter buyer : connectedBuyers) {
                buyer.println(message);
            }
        }
    }

    // Handles the transaction process.
    public synchronized boolean executeTransaction(String product, int amount, int buyerId) {
        Integer stock = inventory.getOrDefault(product, 0); // Get current stock of the product
        if (stock >= amount) {
            inventory.put(product, stock - amount); // Update inventory after successful transaction
            System.out.println("TRANSACTION: BUYER " + buyerId + " PURCHASED " + amount + "  " + product + " FROM SELLER " + id);
            System.out.println("REMAINING GOODS: " + product + " - " + (stock - amount));
            if (inventory.get(product) == 0) {
                rotateInventoryItem(); // Rotate to next item if current item stock depletes
            }

            updateAllBuyers("AVAILABLE: " + activeItem + + inventory.get(activeItem));
            return true;
        } else {
            System.out.println("NOT ENOUGH " + product + " -> ONLY " + stock + "CURRENTLY AVAILABLE");
            return false;
        }
    }

    // Rotates the item for sale based on inventory.
    private void rotateInventoryItem() {
        String[] items = {"FLOUR", "SUGAR", "POTATO", "OIL"};
        int currentIndex = Arrays.asList(items).indexOf(activeItem);

        for (int i = 1; i <= items.length; i++) {
            int nextIndex = (currentIndex + i) % items.length;
            String nextItem = items[nextIndex];

            if (inventory.getOrDefault(nextItem, 0) > 0) {
                activeItem = nextItem;
                System.out.println("NOW SELLING (60 SEC): " + activeItem + " -> FROM SELLER " + id);

                broadcastToBuyers("NOW SELLING (60 SEC): " + activeItem + " -> AMOUNT: " + inventory.get(activeItem));
                break;
            }
        }
    }

    // Broadcasts a message to all connected buyers.
    public void broadcastToBuyers(String message) {
        synchronized (connectedBuyers) {
            for (PrintWriter buyer : connectedBuyers) {
                buyer.println(message);
            }
        }
    }

    // Adds a new buyer connection to the list of connected buyers.
    public void addBuyerConnection(PrintWriter buyerOutput) {
        synchronized (connectedBuyers) {
            connectedBuyers.add(buyerOutput);
        }
    }

    // Removes a buyer connection from the list of connected buyers.
    public void removeBuyerConnection(PrintWriter buyerOutput) {
        synchronized (connectedBuyers) {
            connectedBuyers.remove(buyerOutput);
        }
    }

    // Schedules regular inventory item rotation.
    private void scheduleInventoryRotation() {
        TimerTask rotationTask = new TimerTask() {
            int countdown = 60; // Countdown for item rotation

            @Override
            public void run() {
                if (countdown > 0) {
                    System.out.println("NEW ITEM IN: " + countdown + " SECONDS");
                    countdown -= 10;
                } else {
                    rotateInventoryItem(); // Rotate to the next item
                    countdown = 60; // Reset countdown
                }
            }
        };
        inventoryRotationTimer.scheduleAtFixedRate(rotationTask, 0, 10000); // Schedule task for every 10 seconds
    }

    // Main method to start the Seller application.
    public static void main(String[] args) {
        Properties properties = new Properties();
        try {
            properties.load(new FileReader("Marketplace.properties")); // Load properties file
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // Determine the seller's ID and port based on command-line arguments or properties file.
        int sellerId = Integer.parseInt(args.length > 0 ? args[0] : properties.getProperty("seller1.id"));
        int port = Integer.parseInt(properties.getProperty("seller" + sellerId + ".port"));

        Seller server = new Seller(sellerId, port); // Create a seller instance
        server.initializeInventory(properties); // Initialize the inventory
        new Thread(server).start(); // Start the seller server in a new thread
    }
}
