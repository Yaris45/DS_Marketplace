1. Start the java Seller file to start the server (java Seller)
2. Start the buyer instance using java Buyer followed by buyer number (1-6 etc.) Open more than 1 terminal if you want more buyers.
3. Buyer can specify whatever amount they want of what is on sale. If succesful, confirmation will be sent to buyer and seller. 
4. To exit, simply type exit in the buyer terminal and you will disconnect. 

easy as that. 